package skel;

import java.util.ArrayList;

import processing.core.*;

public class Boid {
	private PApplet graphicalContext;
	private Flock myFlock;
	private PVector pos;
	private PVector vel;
	private Float vitesseMax;
	private Float forceMax;
	private int borneMax = 5;
	private int borneMin = -5;
	private int borneMaxForce = 10;
	private int borneMinForce = -10;
	
	public Boid(PApplet graphicalContext,int x,int y){
		this.graphicalContext = graphicalContext;
		this.vitesseMax = 2f;
		this.forceMax = 0.05f;
		this.pos = new PVector(x,y);
		this.vel = new PVector(
				(int) (Math.random()*(borneMax-(borneMin))+borneMin),
				(int) (Math.random()*(borneMax-(borneMin))+borneMin),
				(int) (Math.random()*(borneMax-(borneMin))+borneMin)
									);
		this.myFlock.addBoid((int)this.pos.x, (int)this.pos.y);
		
	}
	
	public Boid(PApplet graphicalContext,int x,int y,Float vitesseMax, Float forceMax){
		this.graphicalContext = graphicalContext;
		this.vitesseMax = vitesseMax;
		this.forceMax = forceMax;
		this.pos = new PVector(x,y);
		this.vel = new PVector(
				(int) (Math.random()*(borneMax-(borneMin))+borneMin),
				(int) (Math.random()*(borneMax-(borneMin))+borneMin),
				(int) (Math.random()*(borneMax-(borneMin))+borneMin)
									);
	}
	
	public PVector randomForce(){
		return  new PVector(
				(int) (Math.random()*(borneMaxForce-(borneMinForce))+borneMinForce),
				(int) (Math.random()*(borneMaxForce-(borneMinForce))+borneMinForce),
				(int) (Math.random()*(borneMaxForce-(borneMinForce))+borneMinForce));
	}
	
	public void updatePosition(){
		PVector forces = randomForce();
		this.pos.set(
				this.pos.x +( this.vel.x + forces.x),
				this.pos.y + (this.vel.y + forces.y),
				this.pos.z + (this.vel.z + forces.z));
	}
	
	public void run() {
	    this.updatePosition();
	    this.borders();
	    this.render();
	}

	public void render() {
	    // Draw a triangle rotated in the direction of velocity
	    float r = (float) 2.0;
	    float theta = this.vel.heading2D() + PConstants.PI / 2;
	    graphicalContext.fill(200, 100);
	    graphicalContext.stroke(255);
	    graphicalContext.pushMatrix();
	    graphicalContext.translate(this.pos.x, this.pos.y);
	    graphicalContext.rotate(theta);
	    graphicalContext.beginShape(PConstants.TRIANGLES);
	    graphicalContext.vertex(0, -r * 2);
	    graphicalContext.vertex(-r, r * 2);
	    graphicalContext.vertex(r, r * 2);
	    graphicalContext.endShape();
	    graphicalContext.popMatrix();
	    
	}

	public void borders() {
	    float r = (float) 2.0;
	    if (this.pos.x < -r) {
		this.pos.x = graphicalContext.width + r;
	    }
	    
	    if (this.pos.y < -r) {
		this.pos.y = graphicalContext.height + r;
	    }
	    
	    if (this.pos.x > graphicalContext.width + r) {
		this.pos.x = -r;
	    }
	    
	    if (this.pos.y > graphicalContext.height + r) {
		this.pos.y = -r;
	    }
	}
	
	public double distance(Boid b){
		return PVector.dist(b.pos, this.pos);
	}
	
	public PVector steer(PVector target, boolean slowDown) {
	    PVector desired = PVector.sub(target, this.pos);
	    if (desired.mag() <= 0) {
		return new PVector(0, 0);
	    }
	    
	    desired.normalize();
	    if (slowDown && desired.mag() < 100.0) {
		desired.mult((float) (this.vitesseMax * (desired.mag() / 100.0)));
	    } else {
		desired.mult(this.vitesseMax);
	    }
	    
	    PVector steeringVector = PVector.sub(desired, this.vel);
	    steeringVector.limit((float) this.forceMax);
	    return steeringVector;
	}
	
	public PVector align(){
		PVector fAlignement;
		ArrayList<Boid> voisinage = this.myFlock.neighbors(this, 25);
		Float x = 0f,y=0f,z = 0f;
		int sizeV = voisinage.size();
		for(Boid b : voisinage){
			x += b.vel.x;
			y += b.vel.y;
			z += b.vel.z;
		}
		fAlignement = new PVector(0,0,0);
		if (voisinage.size()!=0){
		fAlignement.set(x/sizeV,y/sizeV,z/sizeV); 
		fAlignement.normalize();
		fAlignement.mult(vitesseMax);
		fAlignement.sub(vel);
		fAlignement.limit(vitesseMax);
		}
		return fAlignement;
		
	}
	
	//public PVector separate(){
	    
	//}

		
	
	

}
