package skel;
import java.util.ArrayList;
import java.util.stream.Collector;
import java.util.stream.Collectors;

import processing.core.*;

public class Flock {
	private PApplet graphicalContext;
	private ArrayList<Boid> boids;
	
	public Flock(int n,PApplet graphicalContext){
		boids = new ArrayList<Boid>(n);
		this.graphicalContext = graphicalContext;
		
	}
	
	public void addBoid(int x, int y){
		this.boids.add(new Boid(graphicalContext, x, y));
	}
	
	public void run(){
		for(Boid e : boids){
			e.run();
		}
	}
	
	public ArrayList<Boid> neighbors(Boid b, double neighborDist){
		return this.boids.stream()
				.filter(boid->boid.distance(b) < neighborDist).collect(Collectors.toCollection(ArrayList::new));
		
	}

}
